export default function Gallery() {
  return <section id="gallery" className="py-20 bg-gradient-to-b from-white/50 to-pink-50/50"></section>
}
